#!/bin/bash
#
#************************
#Author:          lixu666
#mail:          1239813177@qq.com
#Date:          2020-02-22
#FileName:          5.sh
#Description:          test script
#Copyright:          2020
#************************
 cd ./lmbench3/src && make
 cd  ../scripts && ./config-run
 ./results
 cd ..
 make see | tee -a ../lmbench.log
 

 
